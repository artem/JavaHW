import java.io.*;
import java.util.*;
import java.lang.*;

public class MyScanner implements AutoCloseable{
    private Reader stream;
    private String nameOfCharSet = "utf8";
    private int readenInt;
    private long readenLong;
    private boolean endFound = false;
    public MyScanner(InputStream io, String anotherNameOfCharSet) throws IOException {
        nameOfCharSet = anotherNameOfCharSet;
        stream = new InputStreamReader(io, nameOfCharSet);
    }
    public MyScanner(InputStream io) throws IOException {
        stream = new InputStreamReader(io, nameOfCharSet);
    }

    public MyScanner(File io, String anotherNameOfCharSet) throws IOException {
        nameOfCharSet = anotherNameOfCharSet;
        stream = new InputStreamReader(new FileInputStream(io), nameOfCharSet);
    }
    public MyScanner(File io) throws IOException {
        stream = new InputStreamReader(new FileInputStream(io), nameOfCharSet);
    }

    public MyScanner(String io, String anotherNameOfCharSet) throws IOException {
        nameOfCharSet = anotherNameOfCharSet;
        stream = new InputStreamReader(new StringBufferInputStream(io), nameOfCharSet);
    }
    public MyScanner(String io) throws IOException {
        stream = new InputStreamReader(new StringBufferInputStream(io), nameOfCharSet);
    }

    public void close() throws IOException {
        stream.close();
    }

    public int read() throws IOException {
        return stream.read();
    }

    public String nextWord() throws IOException {
        char[] buf = new char[1];
        int len = 0;
        boolean word = false;
        while (true) {
            if (!word) {
                int nextSym = read();
                if (nextSym == -1) {
                    return "";
                }
                if (Character.getType((char)nextSym) == Character.CONTROL) {
                    return new String("\n");
                }
                if (Character.isWhitespace((char)nextSym)){
                    continue;
                }
                word = true;
                if (len == buf.length) {
                    buf = Arrays.copyOf(buf, 2 * len);
                }
                buf[len++] = (char)nextSym;
            } else {
                int nextSym = read();
                if (nextSym == -1) {
                    break;
                }
                if (Character.isWhitespace((char)nextSym)) {
                    word = false;
                    break;
                }
                if (len == buf.length) {
                    buf = Arrays.copyOf(buf, 2 * len);
                }
                buf[len++] = (char)nextSym;
            }
        }
        return new String(buf, 0, len);
    }

    public String nextLine() throws  IOException {
        char buf[] = new char[1];
        int len = 0;
        while(true) {
            if (len == buf.length) {
                buf = Arrays.copyOf(buf, 2 * buf.length);
            }
            int curSym = read();
            if (curSym == -1) {
                endFound = true;
                return new String(buf, 0, len);
            }
            buf[len++] = (char)curSym;
            if ('\n'== buf[len - 1]) {
                break;
            }
        }
        if (endFound) {
            return new String(buf, 0, len - 1);
        }
        else {
            return new String(buf, 0, len - 1);
        }
    }
    public boolean getEndFound() throws IOException {
        return endFound;
    }
    public int getInt() throws IOException {
        return readenInt;
    }
    public boolean nextInt() throws IOException {
        String cur = new String(nextWord());
        if (cur.equals("")) {
            return false;
        } else {
            readenInt = Integer.parseInt(cur);
            return true;
        }
    }
    public boolean nextLong() throws IOException {
        String cur = new String(nextWord());
        if (cur.equals("")) {
            return false;
        } else {
            readenLong = Long.parseLong(cur);
            return true;
        }
    }
}
