import java.util.Scanner;
import java.util.Arrays;
import java.io.*;
import java.util.Comparator;

public class ReverseSort {
    public static void solve() {        
        try (MyScanner in = new MyScanner(System.in)) {
            int height = 0;
            long table[][] = new long[1][];                        
            int maxLineLength = 0;
            while (!in.getEndFound()) {                
                String currentLine = in.nextLine();                
                MyScanner currentLineScanner = new MyScanner(currentLine);                
                if (height == table.length) {
                    table = Arrays.copyOf(table, 2 * height);
                }
                long currentLineArray[] = new long[2];
                int currentLineArrayEnd = 1;                
                while (currentLineScanner.nextInt()) {                    
                    if (currentLineArrayEnd == currentLineArray.length) {
                        currentLineArray = Arrays.copyOf(currentLineArray, 2 * currentLineArrayEnd);
                    }
                    long currentInt = currentLineScanner.getInt();
                    currentLineArray[0] += currentInt;                    
                    currentLineArray[currentLineArrayEnd] = currentInt;                    
                }
                if (currentLineArrayEnd == currentLineArray.length) {
                    currentLineArray = Arrays.copyOf(currentLineArray, currentLineArrayEnd + 1);
                }            
                table[height] = Arrays.copyOf(currentLineArray, currentLineArrayEnd);
                maxLineLength = Math.max(maxLineLength, table[height++].length);
                currentLineScanner.close();                
            }
            height--;
            Arrays.sort(table, 0, height + 1, Comparator.compairingLong((a -> table[0])));
            for (int i = height - 1; i >= 0; i--) {
                Arrays.sort(table[i], (int)table[i][0]);
            }
            for (int i = height - 1; i >= 0; i--) {
                for (int j = (int) table[i].length - 1; j >= 0; j--) {
                    System.out.print(table[i][j]);                    
                }
                System.out.println();
            }
            
        } catch (IOException e) {
            System.out.print("IOException : ");
            System.out.println(e.getMessage());
        }
    }
    public static void main(String[] args) {
        solve();
    }
}
